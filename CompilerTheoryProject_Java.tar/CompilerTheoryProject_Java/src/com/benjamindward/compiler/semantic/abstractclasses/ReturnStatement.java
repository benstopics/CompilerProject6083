package com.benjamindward.compiler.semantic.abstractclasses;

public class ReturnStatement extends Statement {
	public ReturnStatement() {
		
	}
}
