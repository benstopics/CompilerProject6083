package com.benjamindward.compiler.semantic.abstractclasses;

import com.benjamindward.compiler.semantic.ast.IRAbstractNode;

public abstract class Declaration extends IRAbstractNode {

}
